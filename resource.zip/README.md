<p>
  <h1 align=center>
    <img src=https://media.discordapp.net/attachments/901618453356630052/977196070171975770/unknown.png?width=450&height=225>
  </h1>
<p align=center>
  Open source resource pack used with the Minecraft network "b"
</p>


<p align=center>
  <!--- Website Status ---->
  <a href=>
    <img src=https://img.shields.io/website?logo=openstreetmap&down_color=lightgrey&down_message=Offline&label=behr.dev&up_message=Online&url=http%3A%2F%2Fbehr.dev>
  </a>
  <!--- Discord Activity ---->
  <a href=https://discord.gg/mpxGDSJkkW>
    <img src=https://img.shields.io/discord/901618453356630046?logo=discord>
  </a>
  <!--- Active Version ---->
	<a href="https://github.com/bGielinor/b-resource/archive/refs/heads/main.zip"><img src="https://img.shields.io/badge/Minecraft%20Version-1.19-c70039?logo=blueprint" alt="Minecraft Version">
  </a>
</p>
<p align=center>
	<!--- Commit Activity ---->
  <a href=https://github.com/Adriftus-Studios/network-script-data/pulse>
    <img src=https://img.shields.io/github/commit-activity/m/bGielinor/b-resource?logo=read-the-docs>
  </a>
	<!--- License ---->
  <a href=https://unlicense.org>
    <img src=https://img.shields.io/badge/License-unlicense-lightgrey.svg>
  </a>
</p>
